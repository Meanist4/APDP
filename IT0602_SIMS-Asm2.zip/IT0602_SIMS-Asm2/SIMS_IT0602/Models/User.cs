﻿using System;
namespace SIMS_IT0602.Models
{
	public class User
	{
		public int Id { get; set; }
		public String UserName { get; set; }
		public String Pass { get; set; }
		public String Role { get; set; }
		public User()
		{
		}
	}
}

